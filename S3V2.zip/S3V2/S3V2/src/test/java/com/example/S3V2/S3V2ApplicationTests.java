package com.example.S3V2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3V2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
