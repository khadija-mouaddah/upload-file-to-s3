package com.example.S3V2.config;

import java.net.URI;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.S3V2.annotation.S3BucketName;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

@Configuration
public class StorageConfig {
	@Value("${access-key}")
	private String accessKey;
	@Value("${secret-key}")
	private String secretAccessKey;
	@Value("${region}")
	private String region;
	@Value("${endPoint}")
	private String endpoint;
	@Value("${bucket}")
	private String bucketName;

	// == beans methods ==
	@Bean
	public S3Client s3Client() {
		AwsCredentials credentials = AwsBasicCredentials.create(accessKey, secretAccessKey);
		Region region = Region.of(this.region);

		return S3Client.builder()
				.credentialsProvider(StaticCredentialsProvider.create(credentials))
				.region(region)
				.endpointOverride(URI.create(endpoint)).build();

	}

	@Bean
	@S3BucketName
	public String s3BucketName() {
		return this.bucketName;
	}

}
